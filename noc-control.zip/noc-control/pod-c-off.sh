#!/bin/bash\
bash ./noc-control/pod-c1.sh &
bash ./noc-control/pod-c2.sh &
bash ./noc-control/pod-c3.sh &
bash ./noc-control/pod-c4.sh &
bash ./noc-control/pod-c5.sh
exit 0
