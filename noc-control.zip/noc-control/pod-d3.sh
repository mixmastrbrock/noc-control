#!/bin/bash\
echo -n -e "ka 01 00" | nc 10.100.212.63 9761
