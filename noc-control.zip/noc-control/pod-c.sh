#!/bin/bash\
wakeonlan -i 10.100.212.56 20:17:42:7E:CD:FB
wakeonlan -i 10.100.212.57 20:17:42:78:C7:85
wakeonlan -i 10.100.212.58 20:17:42:78:CB:1B
wakeonlan -i 10.100.212.59 20:17:42:78:D7:C0
wakeonlan -i 10.100.212.60 20:17:42:78:C8:7D
