#!/bin/bash\
bash ./noc-control/pod-b1.sh &
bash ./noc-control/pod-b2.sh &
bash ./noc-control/pod-b3.sh &
bash ./noc-control/pod-b4.sh &
bash ./noc-control/pod-b5.sh
exit 0
