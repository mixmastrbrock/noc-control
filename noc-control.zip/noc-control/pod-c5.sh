#!/bin/bash\
echo -n -e "ka 01 00" | nc 10.100.212.60 9761
