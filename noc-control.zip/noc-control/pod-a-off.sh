#!/bin/bash\
bash ./noc-control/pod-a1.sh &
bash ./noc-control/pod-a2.sh &
bash ./noc-control/pod-a3.sh &
bash ./noc-control/pod-a4.sh &
bash ./noc-control/pod-a5.sh
exit 0
