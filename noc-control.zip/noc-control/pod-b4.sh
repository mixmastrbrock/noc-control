#!/bin/bash\
echo -n -e "ka 01 00" | nc 10.100.212.54 9761
