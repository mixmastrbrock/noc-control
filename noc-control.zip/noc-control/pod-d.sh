#!/bin/bash\
wakeonlan -i 10.100.212.61 20:17:42:7E:CD:A8
wakeonlan -i 10.100.212.62 20:17:42:7A:62:61
wakeonlan -i 10.100.212.63 64:95:6C:74:94:32
wakeonlan -i 10.100.212.64 20:17:42:78:D7:94
wakeonlan -i 10.100.212.65 20:17:42:78:CC:C0
