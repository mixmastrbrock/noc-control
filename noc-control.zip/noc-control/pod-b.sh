#!/bin/bash\
wakeonlan -i 10.100.212.51 20:17:42:AE:7D:12
wakeonlan -i 10.100.212.52 20:17:42:7D:FF:F7
wakeonlan -i 10.100.212.53 20:17:42:7E:00:70
wakeonlan -i 10.100.212.54 20:17:42:7A:60:5F
wakeonlan -i 10.100.212.55 20:17:42:78:CB:03
