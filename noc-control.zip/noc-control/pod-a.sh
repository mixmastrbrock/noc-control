#!/bin/bash\
wakeonlan -i 10.100.212.46 20:17:42:7E:CD:B4
wakeonlan -i 10.100.212.47 20:17:42:97:2C:A2
wakeonlan -i 10.100.212.48 20:17:42:78:D7:6D
wakeonlan -i 10.100.212.49 20:17:42:78:D7:6F
wakeonlan -i 10.100.212.50 20:17:42:97:25:9B
