#!/bin/bash\
bash ./noc-control/pod-d1.sh &
bash ./noc-control/pod-d2.sh &
bash ./noc-control/pod-d3.sh &
bash ./noc-control/pod-d4.sh &
bash ./noc-control/pod-d5.sh
exit 0
