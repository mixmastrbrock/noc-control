#!/bin/bash\
bash ./noc-control/pod-a1.sh &
bash ./noc-control/pod-a2.sh &
bash ./noc-control/pod-a3.sh &
bash ./noc-control/pod-a4.sh &
bash ./noc-control/pod-a5.sh &
bash ./noc-control/pod-b1.sh &
bash ./noc-control/pod-b2.sh &
bash ./noc-control/pod-b3.sh &
bash ./noc-control/pod-b4.sh &
bash ./noc-control/pod-b5.sh &
bash ./noc-control/pod-c1.sh &
bash ./noc-control/pod-c2.sh &
bash ./noc-control/pod-c3.sh &
bash ./noc-control/pod-c4.sh &
bash ./noc-control/pod-c5.sh &
bash ./noc-control/pod-d1.sh &
bash ./noc-control/pod-d2.sh &
bash ./noc-control/pod-d3.sh &
bash ./noc-control/pod-d4.sh &
bash ./noc-control/pod-d5.sh
end 0
